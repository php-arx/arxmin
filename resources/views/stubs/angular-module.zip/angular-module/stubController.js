
angular.module('{stub}')
    .controller('{stub}Controller', {stub}Controller);


{stub}Controller.$inject = [
    '$window',
    '$scope'
];


function {stub}Controller($window, $scope) { console.log('-> {stub}Controller');

}
